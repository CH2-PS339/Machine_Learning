import re
from flask import Flask, jsonify, request
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
import string

import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

import pickle
import numpy as np

app = Flask(__name__)

def preprocess_text(text):
    text = text.lower()  # Ubah ke huruf kecil
    text = re.sub(r'[^a-z\s\-\(\)]', '', text)  # Hapus karakter khusus
    tokens = word_tokenize(text)  # Tokenisasi
    stop_words = set(stopwords.words('english'))  # Hapus stopwords
    tokens = [word for word in tokens if len(word) > 1]
    processed_text = ' '.join(tokens)  # Gabungkan kembali token menjadi kalimat
    return processed_text

def remove_punctuation(text):
    return text.translate(str.maketrans('', '', string.punctuation))

stemmer = PorterStemmer()

def stemming(text):
    tokens = word_tokenize(text)
    stemmed_tokens = [stemmer.stem(word) for word in tokens]
    return ' '.join(stemmed_tokens)

@app.route('/hello/', methods=['GET', 'POST'])
def welcome():
    return "Hello World!"

@app.route('/predict/', methods=['POST'])
def predict():

    try:
        # get the body of the POST request
        data = request.get_json(force=True)

        

        # convert data into dictionary so i can access it by key
        data = dict(data)

        # if data is empty or not contain ['job_title'] and ['description'] key then return error
        if not data or 'job_title' not in data or 'description' not in data:
            return jsonify({'message': 'No parameter was sent', "status": "Error"})

        # apply preprocessing to the ['job_title'] and ['description'] key
        data['job_title'] = preprocess_text(data['job_title'])
        data['description'] = preprocess_text(data['description'])

        # apply remove punctuation to the ['description'] key
        data['description'] = remove_punctuation(data['description'])

        # apply stemming to the ['description'] key
        data['description'] = stemming(data['description'])

        # extract the ['job_title'] and ['description'] key as a list like df['Job_title'].tolist()
        data['job_title'] = [data['job_title']]
        data['description'] = [data['description']]

        # preprocess the ['job_title'] and ['description'] key
        tokenizer_job_title = Tokenizer(num_words=8000)
        tokenizer_job_title.fit_on_texts(data['job_title'])
        total_words_job_title = len(tokenizer_job_title.word_index) + 1
        sequences_job_title = tokenizer_job_title.texts_to_sequences(data['job_title'])
        max_len_job_title = 15
        padded_sequences_job_title = pad_sequences(sequences_job_title, maxlen=max_len_job_title, padding='post')

        tokenizer_description = Tokenizer(num_words=8000)
        tokenizer_description.fit_on_texts(data['description'])
        total_words_description = len(tokenizer_description.word_index) + 1
        sequences_description = tokenizer_description.texts_to_sequences(data['description'])
        max_len_description = 1000
        padded_sequences_description = pad_sequences(sequences_description, maxlen=max_len_description, padding='post')

        total_words_job_title, max_len_job_title, total_words_description, max_len_description

        # load the model
        model = tf.keras.models.load_model('complete_model.h5')

        # load the label encoder
        with open('label_encoder.pkl', 'rb') as handle:
            label_encoder = pickle.load(handle)

        # predict the data
        prediction = model.predict([padded_sequences_job_title, padded_sequences_description])

        # get the index of the highest probability
        class_index = []
        for i in range(len(prediction)):
            class_index.append(np.argmax(prediction[i]))
        
        # Transform the class index back to the original class label
        class_label = label_encoder.inverse_transform(class_index)
        
        

        print (class_label)
        

        # return json response with 1 additional data named prediction
        return jsonify({'prediction': class_label.tolist(), "status": "success"})
    except:
        return jsonify({"status": "Error", "message": "Something went wrong please check the parameters"})

if __name__ == '__main__':
    try:
        nltk.data.find('stopwords')
    except LookupError:
        nltk.download('stopwords')

    try:
        nltk.data.find('punkt')
    except LookupError:
        nltk.download('punkt')
    app.run(host='0.0.0.0', port=105)